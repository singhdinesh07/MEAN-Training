// export class Products {
//     constructor(public productId: number, public productName: string, public imageUrl: string, public description: string, public price: number, public quantity: number) {

//     }
// }
export class Products {
    productId: number;
    productName: string;
    imageUrl: string;
    description: string;
    price: number;
    quantity: number;
    constructor(productId: number,
        productName: string,
        imageUrl: string,
        description: string,
        price: number,
        quantity: number) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.imageUrl = imageUrl;
        this.price = price;
        this.quantity = quantity;
    }
}
