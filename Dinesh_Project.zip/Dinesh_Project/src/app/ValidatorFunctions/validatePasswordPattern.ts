import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export function validatePasswordPattern(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        console.log(control);

        if (/[A-Z]/.test(control.value) && /[a-z]/.test(control.value) && /[0-9]/.test(control.value)) {
            return null;
        }
        else {
            return { passwordPattern: true }
        }
    }
}

