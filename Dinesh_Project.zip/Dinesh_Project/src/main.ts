import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';// name of module- inbuilt module

import { AppModule } from './app/app.module';// relative path; user defined module


platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
