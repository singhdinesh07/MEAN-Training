import { Injectable } from '@angular/core';
import { Products } from './model/Products';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor() {
    this.productsArr = [
      new Products(101, "Iphone 15 max pro", "../assets/iphone15ProMax.jpg", "Apple Iphone 15 pro max 256gb white colour", 112345, 12),
      new Products(102, "Google Pixel 8", "../assets/googlePixel8.jpg", "Apple Iphone 15 pro max 256gb white colour", 11345, 1),
      new Products(103, "Water Bottle", "../assets/Bottle.jpg", "Apple Iphone 15 pro max 256gb white colour", 300, 5),
      new Products(104, "Potato Chips", "../assets/potato-chips.jpg", "Potato Chipz Salted", 50, 7),
      new Products(105, "Boat Rockerz", "../assets/Boat-Rockerz-450.png", "Apple Iphone 15 pro max 256gb white colour", 2000, 10),
    ];
  }
  addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  }
  getAllProductsItems() {
    return this.productsArr;
  }
  deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
}