import { Injectable } from '@angular/core';
import { Cart } from './model/Cart';

@Injectable()
export class CartManagementService {
  cartArr: Cart[];
  constructor() {
    this.cartArr = [];
  }
  addCartItem(cartObj: Cart) {
    this.cartArr.push(cartObj);
    console.log(this.cartArr)
  }
  getAllCartItems() {
    return this.cartArr;
  }
  deleteCartItem(productId: number) {
    var pos = this.cartArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.cartArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
}
